package com.phase3sportyshoes.bean;

import java.util.Date;
import jakarta.persistence.*;
import lombok.*;
@Getter
@Setter
@Entity
public class PurchaseReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String Productname;
    private String Category;
    private double price;
    private String customer;
    private String customeremail;

    @Temporal(TemporalType.DATE)
    private Date dateOfProductPurchase;

    public PurchaseReport() {
        super();
    }

    public PurchaseReport(String productname, String category, double price, String customer, String customeremail, Date dateOfProductPurchase) {
        Productname = productname;
        Category = category;
        this.price = price;
        this.customer = customer;
        this.customeremail = customeremail;
        this.dateOfProductPurchase = dateOfProductPurchase;
    }

}