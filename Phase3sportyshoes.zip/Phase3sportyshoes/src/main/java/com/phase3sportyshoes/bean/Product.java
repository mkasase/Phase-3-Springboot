package com.phase3sportyshoes.bean;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;


@Getter
@Setter
@Entity
@Table(name = "product")

// Insert line to prevent a Infinite loop when retriving user and product details
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler", "users" })
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int productId;
    private String productName;
    private int productPrice;
    private String category;
    @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE }, mappedBy = "products")
    private List<User> users = new ArrayList<User>();

    public Product(int productId, String productName, int productPrice, String category, List<User> users) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.category = category;
        this.users = users;
    }

    public Product() {

    }

    public void addUser(User user) {
        this.users.add(user);
    }

    @Override
    public String toString() {
        return "Product{" + "productId=" + productId + ", productName='" + productName + '\'' +
                ", productPrice=" + productPrice + ", category='" + category + '\'' + ", users=" + users + '}';
    }
}

