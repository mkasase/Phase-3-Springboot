package com.phase3sportyshoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3sportyshoesApplicationTests {

    @Test
    void contextLoads() {
    }

}
